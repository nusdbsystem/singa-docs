#include "communication/msg.h"

namespace singa {
} /* singa */

